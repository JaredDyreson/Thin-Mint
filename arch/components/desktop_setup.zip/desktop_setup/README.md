# Desktop Environment

This portion will take the longest to perfect

# User configuration

- Allow for someone to be made root
- Get passwords via dialog
- Create the actual user
- Configure the system before an actual user can be created, then call create_user

File is `user_configuration`

# User Applications

- Allow for git, vim, zsh to be configured for usage in the terminal
- Configure rxvt to be installed with necessary fonts and files

File is `user_terminal_conf`

# TESTS
- [ ] User configuration 
- [ ] User applications
- [ ] Themes
